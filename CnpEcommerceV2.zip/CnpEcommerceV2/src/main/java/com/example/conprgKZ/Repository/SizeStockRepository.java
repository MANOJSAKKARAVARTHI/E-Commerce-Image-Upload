package com.example.conprgKZ.Repository;

import com.example.conprgKZ.Entity.SizeStock;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SizeStockRepository extends JpaRepository<SizeStock, Long> {
}