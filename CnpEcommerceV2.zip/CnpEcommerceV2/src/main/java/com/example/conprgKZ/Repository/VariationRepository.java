package com.example.conprgKZ.Repository;


import com.example.conprgKZ.Entity.Variation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VariationRepository extends JpaRepository<Variation, Long> {
}